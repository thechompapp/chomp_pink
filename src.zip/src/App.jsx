import React, { Suspense, lazy, useEffect } from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import PageContainer from "@/layouts/PageContainer"; // Use alias
import QuickAddPopup from "@/components/QuickAddPopup"; // Use alias
import FloatingQuickAdd from "@/components/FloatingQuickAdd"; // Use alias
import useAppStore from "@/hooks/useAppStore"; // Use alias
import { QuickAddProvider } from "@/context/QuickAddContext"; // Use alias

const Home = lazy(() => import("@/pages/Home/index.jsx")); // Use alias
const Trending = lazy(() => import("@/pages/Trending/index.jsx")); // Use alias
const Lists = lazy(() => import("@/pages/Lists/index.jsx")); // Use alias
const MyLists = lazy(() => import("@/pages/Lists/MyLists.jsx")); // Use alias
const ListDetail = lazy(() => import("@/pages/Lists/ListDetail.jsx")); // Use alias
const NightPlanner = lazy(() => import("@/pages/NightPlanner/index.jsx")); // Use alias
const Dashboard = lazy(() => import("@/pages/Dashboard/index.jsx")); // Use alias
const RestaurantDetail = lazy(() => import("@/pages/RestaurantDetail/index.jsx")); // Use alias
const DishDetail = lazy(() => import("@/pages/DishDetail/index.jsx")); // Use alias

const App = React.memo(() => {
  const setUserLists = useAppStore((state) => state.setUserLists);
  const initializeTrendingData = useAppStore((state) => state.initializeTrendingData);

  useEffect(() => {
    const sampleLists = [
      { id: 1, name: "My Favorites", items: [], isPublic: false },
      { id: 2, name: "Must Try", items: [], isPublic: false },
      { id: 3, name: "West Village Gems", items: [], isPublic: false },
    ];
    setUserLists(sampleLists);
    initializeTrendingData();
  }, [setUserLists, initializeTrendingData]);

  return (
    <Router>
      <QuickAddProvider>
        <PageContainer>
          <Suspense fallback={<div className="flex justify-center items-center h-screen"><div className="text-[#D1B399] text-lg">Loading...</div></div>}>
            <Routes>
              <Route path="/" element={<Home />} />
              <Route path="/trending" element={<Trending />} />
              <Route path="/lists" element={<Lists />}>
                <Route path=":id" element={<ListDetail />} />
                <Route path="my-lists" element={<MyLists />} />
              </Route>
              <Route path="/night-planner" element={<NightPlanner />} />
              <Route path="/dashboard" element={<Dashboard />} />
              <Route path="/restaurant/:id" element={<RestaurantDetail />} />
              <Route path="/dish/:id" element={<DishDetail />} />
              <Route path="/search" element={<Home />} />
            </Routes>
            <QuickAddPopup />
            <FloatingQuickAdd />
          </Suspense>
        </PageContainer>
      </QuickAddProvider>
    </Router>
  );
});

export default App;