import React, { useCallback, useEffect, useRef, useState, useMemo } from "react";
import useAppStore from "@/hooks/useAppStore"; // Use alias
import Button from "./Button";
import { useQuickAdd } from "@/context/QuickAddContext"; // Use alias

// Mock API for location autofill (simulating Google Places API)
const mockLocationApi = (name) => {
  const locationMap = {
    "Joe's Pizza": { city: "New York", neighborhood: "Greenwich Village" },
    "Shake Shack": { city: "New York", neighborhood: "Midtown" },
    "Katz's Delicatessen": { city: "New York", neighborhood: "Lower East Side" },
  };
  return locationMap[name] || { city: "Unknown", neighborhood: "Unknown" };
};

// Suggested hashtags for easy data entry
const suggestedHashtags = [
  "pizza", "burger", "italian", "american", "deli", "vegetarian", "vegan", "spicy", "dessert", "brunch"
];

// Memoize to prevent unnecessary re-renders
const QuickAddPopup = React.memo(() => {
  const { quickAdd, closeQuickAdd, openQuickAdd } = useQuickAdd();
  const addToList = useAppStore((state) => state.addToList);
  const addPendingSubmission = useAppStore((state) => state.addPendingSubmission);
  const userLists = useAppStore((state) => state.userLists);
  const modalRef = useRef(null);

  // State for new list form
  const [newListName, setNewListName] = useState("");
  const [isPublic, setIsPublic] = useState(false);

  // State for new restaurant/dish form
  const [newItemName, setNewItemName] = useState("");
  const [newItemTags, setNewItemTags] = useState([]);
  const [location, setLocation] = useState({ city: "", neighborhood: "" });

  // Memoize quickAdd.selectedItem to prevent reference changes
  const selectedItem = useMemo(() => quickAdd.selectedItem, [quickAdd.selectedItem]);

  // Handle clicks outside the modal
  const handleClickOutside = useCallback((event) => {
    if (modalRef.current && !modalRef.current.contains(event.target)) {
      closeQuickAdd();
    }
  }, [closeQuickAdd]);

  useEffect(() => {
    if (quickAdd.isOpen) {
      document.addEventListener("mousedown", handleClickOutside);
      // Autofill location for restaurants
      if (selectedItem?.type === "restaurant" && selectedItem?.name) {
        const locationData = mockLocationApi(selectedItem.name);
        setLocation(locationData);
      }
    }
    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, [quickAdd.isOpen, selectedItem, handleClickOutside]);

  const handleAdd = useCallback(
    (listId) => {
      console.log("handleAdd called: listId=", listId);
      if (selectedItem && listId) {
        addToList(listId, selectedItem);
        closeQuickAdd();
      }
    },
    [selectedItem, addToList, closeQuickAdd]
  );

  const handleClose = useCallback(() => {
    console.log("handleClose called");
    closeQuickAdd();
  }, [closeQuickAdd]);

  const handleCreateList = () => {
    if (newListName.trim()) {
      const newList = {
        id: Date.now(),
        name: newListName,
        items: selectedItem ? [selectedItem] : [],
        isPublic,
        savedCount: 0,
      };
      addToList(newList.id, selectedItem, true);
      closeQuickAdd();
    }
  };

  const handleAddTag = (tag) => {
    if (!newItemTags.includes(tag)) {
      setNewItemTags([...newItemTags, tag]);
    }
  };

  const handleRemoveTag = (tag) => {
    setNewItemTags(newItemTags.filter((t) => t !== tag));
  };

  const handleSubmitItem = () => {
    if (newItemName.trim()) {
      const newItem = {
        id: Date.now(),
        name: newItemName,
        type: selectedItem?.type,
        tags: newItemTags,
        ...(selectedItem?.type === "restaurant" && {
          city: location.city,
          neighborhood: location.neighborhood,
        }),
        ...(selectedItem?.type === "dish" && {
          restaurant: selectedItem?.restaurant || "Unknown",
        }),
        status: "pending",
      };
      addPendingSubmission(newItem);
      closeQuickAdd();
    }
  };

  if (!quickAdd.isOpen) return null;

  // Add to List Mode
  if (selectedItem && selectedItem.type !== "list") {
    return (
      <div className="fixed inset-0 bg-black/40 flex items-center justify-center p-4 z-50">
        <div ref={modalRef} className="bg-white rounded-lg shadow-lg max-w-md w-full p-6">
          <h3 className="text-xl font-bold text-gray-900 mb-3">Add to List</h3>
          <p className="text-gray-600 mb-5 text-sm">Select a list for "{selectedItem.name}":</p>
          <div className="space-y-2 max-h-60 overflow-y-auto mb-5">
            {userLists.map((list) => (
              <div
                key={list.id}
                className="border border-gray-200 rounded-lg p-3 flex justify-between items-center cursor-pointer hover:border-[#D1B399]"
                onClick={() => handleAdd(list.id)}
              >
                <span className="text-gray-800 font-medium">{list.name}</span>
                <Button variant="primary" size="sm" className="px-3 py-1">
                  +
                </Button>
              </div>
            ))}
          </div>
          <div className="flex justify-end gap-3">
            <Button onClick={handleClose} variant="tertiary" className="px-4 py-2">
              Cancel
            </Button>
            <Button onClick={() => openQuickAdd({ type: "list", item: selectedItem })} variant="primary" className="px-4 py-2">
              Create New List
            </Button>
          </div>
        </div>
      </div>
    );
  }

  // Create New List Mode
  if (selectedItem?.type === "list") {
    return (
      <div className="fixed inset-0 bg-black/40 flex items-center justify-center p-4 z-50">
        <div ref={modalRef} className="bg-white rounded-lg shadow-lg max-w-md w-full p-6">
          <h3 className="text-xl font-bold text-gray-900 mb-3">Create New List</h3>
          <input
            type="text"
            placeholder="List name"
            value={newListName}
            onChange={(e) => setNewListName(e.target.value)}
            className="w-full py-2 px-3 mb-4 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#D1B399]"
          />
          <div className="flex items-center mb-5">
            <label className="flex items-center cursor-pointer">
              <div className="relative">
                <input
                  type="checkbox"
                  checked={isPublic}
                  onChange={() => setIsPublic(!isPublic)}
                  className="sr-only"
                />
                <div className={`w-10 h-6 bg-gray-300 rounded-full shadow-inner ${isPublic ? "bg-[#D1B399]" : ""}`}></div>
                <div
                  className={`absolute w-4 h-4 bg-white rounded-full shadow top-1 left-1 transition-transform ${
                    isPublic ? "translate-x-4" : ""
                  }`}
                ></div>
              </div>
              <span className="ml-3 text-gray-600 text-sm">Make this list public</span>
            </label>
          </div>
          <div className="flex justify-end gap-3">
            <Button onClick={handleClose} variant="tertiary" className="px-4 py-2">
              Cancel
            </Button>
            <Button onClick={handleCreateList} variant="primary" className="px-4 py-2">
              Create List
            </Button>
          </div>
        </div>
      </div>
    );
  }

  // Add New Restaurant/Dish Mode
  return (
    <div className="fixed inset-0 bg-black/40 flex items-center justify-center p-4 z-50">
      <div ref={modalRef} className="bg-white rounded-lg shadow-lg max-w-md w-full p-6">
        <h3 className="text-xl font-bold text-gray-900 mb-3">
          Add New {selectedItem?.type === "restaurant" ? "Restaurant" : "Dish"}
        </h3>
        <input
          type="text"
          placeholder={selectedItem?.type === "restaurant" ? "Restaurant name" : "Dish name"}
          value={newItemName}
          onChange={(e) => setNewItemName(e.target.value)}
          className="w-full py-2 px-3 mb-4 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#D1B399]"
        />
        {selectedItem?.type === "restaurant" && (
          <div className="mb-4">
            <p className="text-gray-600 text-sm mb-2">Location (autofilled):</p>
            <p className="text-gray-800">{location.neighborhood}, {location.city}</p>
          </div>
        )}
        <div className="mb-4">
          <p className="text-gray-600 text-sm mb-2">Tags:</p>
          <div className="flex flex-wrap gap-2 mb-2">
            {newItemTags.map((tag) => (
              <span
                key={tag}
                className="px-3 py-1 bg-[#D1B399] text-white rounded-full text-sm flex items-center"
              >
                #{tag}
                <button onClick={() => handleRemoveTag(tag)} className="ml-2 text-white">
                  ×
                </button>
              </span>
            ))}
          </div>
          <div className="flex flex-wrap gap-2">
            {suggestedHashtags
              .filter((tag) => !newItemTags.includes(tag))
              .map((tag) => (
                <button
                  key={tag}
                  onClick={() => handleAddTag(tag)}
                  className="px-3 py-1 bg-gray-100 rounded-full text-sm text-gray-600 hover:bg-[#D1B399] hover:text-white"
                >
                  #{tag}
                </button>
              ))}
          </div>
        </div>
        <div className="flex justify-end gap-3">
          <Button onClick={handleClose} variant="tertiary" className="px-4 py-2">
            Cancel
          </Button>
          <Button onClick={handleSubmitItem} variant="primary" className="px-4 py-2">
            Submit for Review
          </Button>
        </div>
      </div>
    </div>
  );
});

export default QuickAddPopup;