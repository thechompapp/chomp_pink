import React from "react";
import { Plus } from "lucide-react";
import { useQuickAdd } from "@/context/QuickAddContext"; // Use alias

const FloatingQuickAdd = () => {
  const { openQuickAdd } = useQuickAdd();

  return (
    <button
      onClick={() => openQuickAdd({ type: "restaurant" })}
      className="fixed bottom-6 right-6 w-14 h-14 bg-[#D1B399] rounded-full flex items-center justify-center text-white shadow-lg hover:bg-[#b89e89]"
      aria-label="Add new item"
    >
      <Plus size={24} />
    </button>
  );
};

export default FloatingQuickAdd;