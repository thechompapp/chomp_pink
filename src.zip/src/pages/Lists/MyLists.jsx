import React, { useState } from "react";
import useAppStore from "@/hooks/useAppStore"; // Use alias
import ListCard from "./ListCard";
import { useQuickAdd } from "@/context/QuickAddContext"; // Use alias

const MyLists = () => {
  const [tab, setTab] = useState("created"); // Toggle between "created" and "following"
  const userLists = useAppStore((state) => state.userLists);
  const { openQuickAdd } = useQuickAdd();

  const createdLists = userLists.filter((list) => !list.isFollowing);
  const followingLists = userLists.filter((list) => list.isFollowing);

  const handleCreateNewList = () => {
    openQuickAdd({ type: "list" });
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 md:px-8 py-12">
        {/* Header */}
        <div className="flex justify-between items-center mb-8">
          <h1 className="text-3xl font-bold text-gray-800">My Lists</h1>
          <button
            onClick={handleCreateNewList}
            className="px-4 py-2 bg-[#D1B399] text-white rounded-lg font-medium hover:bg-[#b89e89]"
          >
            Create New List
          </button>
        </div>

        {/* Toggle Tabs */}
        <div className="flex mb-6 border-b border-gray-200">
          <button
            onClick={() => setTab("created")}
            className={`px-4 py-2 font-medium ${
              tab === "created"
                ? "border-b-2 border-[#D1B399] text-[#D1B399]"
                : "text-gray-500 hover:text-[#D1B399]"
            }`}
          >
            Created
          </button>
          <button
            onClick={() => setTab("following")}
            className={`px-4 py-2 font-medium ${
              tab === "following"
                ? "border-b-2 border-[#D1B399] text-[#D1B399]"
                : "text-gray-500 hover:text-[#D1B399]"
            }`}
          >
            Following
          </button>
        </div>

        {/* Lists */}
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
          {tab === "created" &&
            (createdLists.length > 0 ? (
              createdLists.map((list) => (
                <ListCard
                  key={list.id}
                  id={list.id}
                  name={list.name}
                  itemCount={list.items?.length || 0}
                  savedCount={list.savedCount || 0}
                  city={list.city}
                  tags={list.tags || []}
                  isFollowing={list.isFollowing}
                />
              ))
            ) : (
              <p className="text-gray-500">You haven't created any lists yet.</p>
            ))}
          {tab === "following" &&
            (followingLists.length > 0 ? (
              followingLists.map((list) => (
                <ListCard
                  key={list.id}
                  id={list.id}
                  name={list.name}
                  itemCount={list.items?.length || 0}
                  savedCount={list.savedCount || 0}
                  city={list.city}
                  tags={list.tags || []}
                  isFollowing={list.isFollowing}
                />
              ))
            ) : (
              <p className="text-gray-500">You aren't following any lists yet.</p>
            ))}
        </div>
      </div>
    </div>
  );
};

export default MyLists;