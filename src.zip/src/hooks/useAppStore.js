import { create } from "zustand";

const useAppStore = create((set) => ({
  trendingItems: [],
  setTrendingItems: (items) => set({ trendingItems: items }),
  trendingDishes: [],
  setTrendingDishes: (dishes) => set({ trendingDishes: dishes }),
  popularLists: [],
  setPopularLists: (lists) => set({ popularLists: lists }),
  userLists: [],
  setUserLists: (lists) => set({ userLists: lists }),
  activeFilters: { city: null, neighborhood: null, tags: [] },
  searchQuery: "",
  plans: [],
  pendingSubmissions: [],

  // Add to list
  addToList: (listId, item, isNewList = false) => set((state) => {
    const updatedLists = isNewList
      ? [...state.userLists, { ...item, id: listId }]
      : state.userLists.map((list) =>
          list.id === listId ? { ...list, items: [...(list.items || []), item] } : list
        );
    return { userLists: updatedLists };
  }),

  // Toggle follow list
  toggleFollowList: (listId) => set((state) => {
    const updatedLists = state.userLists.map((list) =>
      list.id === listId ? { ...list, isFollowing: !list.isFollowing } : list
    );
    const updatedPopularLists = state.popularLists.map((list) =>
      list.id === listId ? { ...list, isFollowing: !list.isFollowing } : list
    );
    return { userLists: updatedLists, popularLists: updatedPopularLists };
  }),

  // Add pending submission
  addPendingSubmission: (item) => set((state) => ({
    pendingSubmissions: [...state.pendingSubmissions, item],
  })),

  // Approve pending submission
  approveSubmission: (itemId) => set((state) => {
    const item = state.pendingSubmissions.find((s) => s.id === itemId);
    if (!item) return state;

    let updatedItems = [...state.trendingItems];
    let updatedDishes = [...state.trendingDishes];

    if (item.type === "restaurant") {
      updatedItems.push({ ...item, status: "approved" });
    } else if (item.type === "dish") {
      updatedDishes.push({ ...item, status: "approved" });
    }

    return {
      trendingItems: updatedItems,
      trendingDishes: updatedDishes,
      pendingSubmissions: state.pendingSubmissions.filter((s) => s.id !== itemId),
    };
  }),

  // Reject pending submission
  rejectSubmission: (itemId) => set((state) => ({
    pendingSubmissions: state.pendingSubmissions.filter((s) => s.id !== itemId),
  })),

  // Initialize trending data
  initializeTrendingData: () =>
    set({
      trendingItems: [
        {
          id: 1,
          name: "Joe's Pizza",
          neighborhood: "Greenwich Village",
          city: "New York",
          tags: ["pizza", "italian"],
          adds: 78,
        },
        {
          id: 2,
          name: "Shake Shack",
          neighborhood: "Midtown",
          city: "New York",
          tags: ["burger", "american"],
          adds: 52,
        },
      ],
      trendingDishes: [
        {
          id: 1,
          name: "Margherita Pizza",
          restaurant: "Joe's Pizza",
          tags: ["pizza", "vegetarian"],
          price: "$$ • ",
          adds: 78,
        },
        {
          id: 2,
          name: "ShackBurger",
          restaurant: "Shake Shack",
          tags: ["burger", "beef"],
          price: "$$ • ",
          adds: 52,
        },
      ],
      popularLists: [
        {
          id: 1,
          name: "NYC Pizza Tour",
          itemCount: 5,
          savedCount: 120,
          city: "New York",
          tags: ["pizza", "nyc"],
          isFollowing: false,
        },
      ],
    }),
}));

export default useAppStore;